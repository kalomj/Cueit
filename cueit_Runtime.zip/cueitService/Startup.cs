using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(cueitService.Startup))]

namespace cueitService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureMobileApp(app);
        }
    }
}